using System.Collections.Generic;
using The_Wall.Models;

namespace The_Wall.Models
{
    public class Message_Comment
    {
        public Messages Messages { get; set; }
        public Comments Comments { get; set; }
    }
}